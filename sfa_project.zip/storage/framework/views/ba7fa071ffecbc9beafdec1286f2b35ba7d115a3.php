;
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Content'); ?>
<!--begin::Card-->
<div class="card">

    <!--begin::Card body-->
    <div class="card-body py-4">
        <!--begin::Table-->
        <div id="kt_table_users_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
            <div class="table-responsive">
                <table class="table align-middle table-row-dashed fs-6 gy-5 dataTable no-footer" id="kt_table_users">
                    <!--begin::Table head-->
                    <thead>
                        <!--begin::Table row-->
                        <tr class="text-start text-muted fw-bold fs-7 text-uppercase gs-0">

                            <th class="min-w-125px sorting" tabindex="0" aria-controls="kt_table_users" rowspan="1" colspan="1" aria-label="User: activate to sort column ascending" style="width: 206.375px;"><?php echo e(__('cms.models')); ?></th>



                            <th class="min-w-125px sorting" tabindex="0" aria-controls="kt_table_users" rowspan="1" colspan="1" aria-label="Joined Date: activate to sort column ascending" style="width: 142.234px;"><?php echo e(__('cms.status')); ?></th>


                        </tr>
                        <!--end::Table row-->
                    </thead>
                    <!--end::Table head-->
                    <!--begin::Table body-->
                    <tbody class="text-gray-600 fw-semibold">

                        <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productmodel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($productmodel->name); ?></td>
                            <td>
                                <div class="form-group clearfix align-middle">
                                    <div class="icheck-success d-inline">
                                        <input class="form-check-input " type="checkbox" onclick="performUpdate('<?php echo e($productmodel->id); ?>')" id="models-<?php echo e($productmodel->id); ?>" <?php if($productmodel->granted): echo 'checked'; endif; ?>

                                        >
                                        <label class="form-check-label ms-3" for="productmodel_<?php echo e($productmodel->id); ?>"></label>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <!--end::Table body-->
                </table>
            </div>
        </div>
        <!--end::Table-->
    </div>
    <!--end::Card body-->
</div>
<!--end::Card-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script>
    $(function() {
        bsCustomFileInput.init()
    });
</script>
<script>
    function performUpdate(id) {
        axios.put('/cms/UserModel/store', {
                product_models_id: id,
            })
            .then(function(response) {
                console.log(response);
                toastr.success(response.data.message);
            })
            .catch(function(error) {
                console.log(error.response);
                toastr.error(error.response.data.message);
            });
    }
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sfa_project\resources\views/cms/user_model/create.blade.php ENDPATH**/ ?>